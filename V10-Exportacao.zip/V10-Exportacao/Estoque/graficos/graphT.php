<?php
require('../protected.php');

if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['id'])) {
    die('Você não pode acessar esta página porque não está logado.<p><a href="../login/index.html">Entrar</a></p>');
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ../login/index.html");
    exit;
}

// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "tucas";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro de conexão com o banco de dados: " . $conn->connect_error);
}

// Consulta SQL para obter os valores da tabela
$sql = "SELECT nome, entradas FROM estoque";
$result = $conn->query($sql);

$dadosGastos = [];
$labels = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $labels[] = $row['nome'];
        $dadosGastos[] = $row['entradas'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../tucano (1).png" type="image/png">
    <title>Gastos</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 0;
        }

        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logout a {
            background-color: #F2C063;
            color: #F2E6CE;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-right: 60px;
        }

        .grafico-container {
            margin-top: 250px;
            width: 800px;
            height: 600px;
        }
    </style>
</head>

<body>
    <div class="top-bar">
        <div class="logo">
            <a href="javascript:history.back()">
                <img src="../tela_inicial/tucano (1).png" alt="Logo Icon" class="logo-icon">
            </a>
            <span class="logo-text">Tucas - Finanças - Gastos</span>
        </div>
        <div class="logout">
            <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> Sair</a>
        </div>
    </div>

    <div class="grafico-container">
        <canvas id="canvasGrafico"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        window.onload = function () {
            var ctx = document.getElementById("canvasGrafico").getContext("2d");

            // Dados dos gastos por produto
            var dadosGastos = <?php echo json_encode($dadosGastos); ?>;
            var labels = <?php echo json_encode($labels); ?>;

            new Chart(ctx, {
                type: "bar",
                data: {
                    labels: labels,
                    datasets: [{
                        label: "Entradas Totais",
                        data: dadosGastos,
                        backgroundColor: "rgba(255, 0, 0, 0.2)", // Fundo vermelho
                        borderColor: "rgba(255, 0, 0, 1)", // Borda vermelha
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        };
    </script>
</body>

</html>