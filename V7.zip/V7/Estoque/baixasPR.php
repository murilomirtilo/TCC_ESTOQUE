<?php
    require("conn.php");
    require("protected.php");
    $tabela = $pdo->prepare("SELECT id_baixaPR, avaria_produtoR, data_PR, nome_PR, patrimonio, responsavel
    FROM baixa_pr;");
    $tabela->execute();
    $rowTabela = $tabela->fetchAll();
    
    /*
    if (empty($rowTabela)){
        echo "<script>
        alert('Tabela vazia!!!');
        </script>";
    } */
    if (isset($_SESSION['id'])) {
        $usuarioLogadoId = $_SESSION['id'];


    }
?>
<!DOCTYPE HTML>
<html lang="pt-br">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title>Histórico de baixas de produtos retornáveis</title>
        <link rel="stylesheet" href="styleSideBar.css"> 
        <link rel="shortcut icon" href="imagens/tucano.png" type="image/png">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"> 
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/icons/bootstrap-icons.min.css" rel="stylesheet">
        <link rel="stylesheet" href="styleTabela.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    <body>
    
        <div class="container">
            <h1 style="text-align:center;">Histórico de baixas de produtos retornáveis</h1>
            <br>  
        <table class="table">
        <thead>
        <tr>
            <th scope="col"><b>PATRIMÔNIO</b></th>
            <th scope="col"><b>ITEM</b></th>
            <th scope="col"><b>CAUSA / AVARIA</b></th>
            <th scope="col"><b>RESPONSÁVEL</b></th>
            <th scope="col"><b>DATA DA BAIXA</b></th>
            </tr>
        </thead>
        <tbody>
        <?php
    foreach ($rowTabela as $linha){
        echo '<tr>';
        echo "<th scope='row'><b>".$linha['patrimonio']."</th></b>";
        echo "<td>".$linha['nome_PR']."</td>";
        echo "<td>".$linha['avaria_produtoR']."</td>";
        echo "<td>".$linha['responsavel']."</td>";
        echo "<td>".$linha['data_PR']."</td>";
        echo '</tr>';
    }
    ?>
        </tbody>



<!-- SIDEBAR -->
<div class="barraTop">
<div class="logo">

      <span></span>
    </button>
    <button type="button" onclick="toggleSidebar()"class="toggle toggles" id="toggles">
      <span onclick="toggleSidebar()"></span>
    </button>

            <img src="imagens/tucano.png" alt="Logo Icon" class="logo-icon">
        </a>

            <span class="logo-text">Tucas</span>
        </div>
        
        <div class="logout">
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
        </div>

    </div>




  <div class="sidebar">
  <script>
  function toggleSidebar() {
  var sidebar = document.querySelector('.sidebar');
  sidebar.classList.toggle('sidebar-closed');
}
  </script>
    <ul class="custom-list">
      <li>.</li>
      <li>.</li>
      <li>.</li>
      
      <li class="nav-item-bobo">
		    <a class="nav-link" data-bs-toggle="collapse" data-bs-target="#menu_item2" href="#"> Produtos de uso único <i class="bi small bi-caret-down-fill h3"></i> </a>
		    <ul id="menu_item2" class="submenu collapse" data-bs-parent="#nav_accordion">
              
              <li class="nav-item-baba">
                  <a class="nav-link tabelaPrincipal"  onclick="redirecionarParaPaginaTabelas()" href="#"><i class="fas fa-search"></i> Tabela </a>                  
              </li>
              <script>

    function redirecionarParaPaginaTabelas() {
        window.location.href = "tabelas.php";
    }
</script> 

              <li class="nav-item-baba">
                  <a onclick="redirecionarParaPaginaHistorico()" hrfe="tabelasEMPR.php" class="nav-link tabelaHistorico" href="#"><i class="far fa-clock"></i> Histórico </a>
              </li>
<script>
    function redirecionarParaPaginaHistorico() {
        window.location.href = "tabelasEMPR.php";
    }
</script> 

<li class="nav-item-baba">
                  <a onclick="redirecionarParaPaginaBaixas()" hrfe="tabelasBAIXAS.php" class="nav-link tabelaBaixas" href="#"><i class="fas fa-arrow-circle-down"></i> Baixas </a>
              </li>
<script>
    function redirecionarParaPaginaBaixas() {
        window.location.href = "tabelasBAIXAS.php";
    }
</script>  

		    </ul>
	  </li>   
    
    

    
    <li class="nav-item-bobo">
		    <a class="nav-link" data-bs-toggle="collapse" data-bs-target="#menu_item2" href="#"> Produtos retornáveis <i class="bi small bi-caret-down-fill h3"></i> </a>
		    <ul id="menu_item2" class="submenu collapse" data-bs-parent="#nav_accordion">
              
        </li>
              <li class="nav-item-baba">
                  <a onclick="redirecionarParaPaginaPR()" hrfe="tabelasPR.php" class="nav-link tabelaHistorico" href="#"><i class="fas fa-search"></i> Tabela</a>
              </li>
<script>
    function redirecionarParaPaginaPR() {
        window.location.href = "tabelasPR.php";
    }
</script>    

              <li class="nav-item-baba">
                  <a onclick="redirecionarParaHistoricoPR()" hrfe="tabelasPR.php" class="nav-link tabelaHistoricoPR" href="#"><i class="far fa-clock"></i> Histórico </a>
              </li>
<script>
    function redirecionarParaHistoricoPR() {
        window.location.href = "historicoPR.php";
    }
</script>

              <li class="nav-item-baba">
                  <a onclick="redirecionarParaBaixasPR()" style="opacity:50%;"hrfe="tabelasPR.php" class="nav-link tabelaHistorico" href="#"><i class="fas fa-arrow-circle-down"></i> Baixas <a>
              </li>
<script>
    function redirecionarParaBaixasPR() {
        window.location.href = "baixasPR.php";
    }
</script>    

		    </ul>
	  </li>     

    <li class="nav-item-bobo">
		    <a class="nav-link" data-bs-toggle="collapse" data-bs-target="#menu_item2" href="#"> Chaves <i class="bi small bi-caret-down-fill h3"></i> </a>
		    <ul id="menu_item2" class="submenu collapse" data-bs-parent="#nav_accordion">
              
        </li>
              <li class="nav-item-baba">
                  <a onclick="redirecionarParaPaginaChaves()" hrfe="tabelasPR.php" class="nav-link tabelaHistorico" href="#"><i class="fas fa-key"></i> Chaves</a>
              </li>
<script>
    function redirecionarParaPaginaChaves() {
        window.location.href = "tabelasCHAVE.php";
    }
</script>     

		    </ul>
	  </li>         

    </ul>

  <script type="text/javascript">

document.addEventListener("DOMContentLoaded", function(){

  document.querySelectorAll('.sidebar .nav-link').forEach(function(element){

    element.addEventListener('click', function (e) {

      let nextEl = element.nextElementSibling;
      let parentEl  = element.parentElement;	

      if(nextEl) {
        e.preventDefault();	
        let mycollapse = new bootstrap.Collapse(nextEl);

          if(nextEl.classList.contains('show')){
            mycollapse.hide();
          } else {
            mycollapse.show();
            // find other submenus with class=show
            var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
            // if it exists, then close all of them
          if(opened_submenu){
            new bootstrap.Collapse(opened_submenu);
          }

          }
        }

    });
  })

}); 
// DOMContentLoaded  end
</script>


                                        <!-- SIDEBAR FIM -->

  <script src="script.js"></script>
        
        </table>
  <!-- Modal REGISTRAR -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.3.0/mdb.min.css" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/a5a5afe9dc.js" crossorigin="anonymous"></script>

<script>
  function validarQuantidade() {
    var quantidadeInput = document.getElementById("qtd_prod");
    var quantidade = parseInt(quantidadeInput.value);
    
    if (isNaN(quantidade) || quantidade % 1 !== 0) {
      alert("A quantidade deve ser um número inteiro.");
      return false; // Impede o envio do formulário
    }
    
    return true; // Permite o envio do formulário
  }
</script>

<div class="modal fade" id="registrationModal" tabindex="-1" role="dialog" aria-labelledby="registrationModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="registrationModalLabel">Registrar Produto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="CRUDE/cad_prod.php" method="POST" onsubmit="return validarQuantidade();">
          <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" class="form-control" id="name_prod" name="name_prod">
          </div>
          <div class="form-group">
            <label for="quantidade">Quantidade</label>
            <input type="text" class="form-control" id="qtd_prod" name="qtd_prod">
          </div>
          <div class="form-group">
            <label for="valor">Local</label>
            <input type="text" class="form-control" id="valor_prod" name="valor_prod">
          </div>
          <div class="form-group">
            <label for="categoria">Categoria</label>
            <input type="text" class="form-control" id="cat_prod" name="cat_prod">
          </div>
          <button type="submit" class="btn btn-primary">Registrar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal PERFILLLLLLL MAIS POLVORAAAA -->

<div class="modal fade" id="perfilModal" tabindex="-1" role="dialog" aria-labelledby="perfilModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="perfilModalLabel">Meu perfil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php

// Configurações do banco de dados

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "EstoqueRenisson";

// Cria uma conexão com o banco de dados
$conn2 = new mysqli($servername, $username, $password, $dbname);

// Verifica se a conexão foi estabelecida com sucesso
if ($conn2->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn2->connect_error);
}

// Recupera o ID do usuário logado (substitua essa parte com a lógica de autenticação do seu sistema)

// Consulta SQL para selecionar as informações do usuário logado
$sqlPerfil = "SELECT id, login, email FROM usuarios WHERE id = $usuarioLogadoId";
$resultPerfil = $conn2->query($sqlPerfil);

// Verifica se foi encontrado um registro
if ($resultPerfil->num_rows == 1) {
    // Recupera os dados do usuário logado
    $row = $resultPerfil->fetch_assoc();
    $id = $row["id"];
    $login = $row["login"];
    $email = $row["email"];

    // Exibe os dados no modal
  echo'  <div class="container">';
  echo'  <div class="row">';
  echo'    <div class="col-md-12">';
  echo'      <p><strong>ID:</strong> <span id="perfilID">';echo($id); echo'</span></p>';
  echo'      <p><strong>Nome:</strong> <span id="perfilNome">';echo($login); echo'</span></p>';
  echo'      <p><strong>Email:</strong> <span id="perfilEmail">';echo($email); echo'</span></p>';
  echo'    </div>';
  echo'  </div>';
  echo' </div>';
} else {
    echo "Nenhum registro encontrado.";
}

?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal EDITAR -->

  <div class="modal fade" id="editarModalLabel" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
    
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editarModalLabel">Editar produto</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="CRUDE/edit_prod.php" method="POST">
            
            <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" id="name_prod" name="name_prod" value="">
            </div>
            <div class="form-group">
              <label for="quantidade">Quantidade</label>
              <input type="text" class="form-control" id="qtd_prod" name="qtd_prod" value="">
            </div>
            <div class="form-group">
              <label for="valor">Local</label>
              <input type="text" class="form-control" id="valor_prod" name="valor_prod" value="">
            </div>
            <div class="form-group">
              <label for="categoria">Categoria</label>
              <input type="text" class="form-control" id="cat_prod" name="cat_prod" value="">
            </div>

            <input type="hidden" id="id_prod" name="id_prod" value="">      
            <button type="submit" class="btn btn-primary">Editar</button>
        </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

        </div>
      </div>
    </div>
  </div>  

<!-- Modal EMPRESTIMO -->

<div class="modal fade" id="emprestimoModalLabel" tabindex="-1" role="dialog" aria-labelledby="emprestimoModalLabel" aria-hidden="true">
    
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="emprestimoModalLabel">Empréstimo produto</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="CRUDE/emprestimo_prod.php" method="POST">
            
            <div class="form-group">
              <label for="quantidade">Quantidade a dar baixa</label>
              <input type="text" class="form-control" id="qtd_prod" name="qtd_prod" value="">
            </div>
            <div class="form-group">
              <label for="quantidade">Mutuário</label>
              <input type="text" class="form-control" id="mutuario_empr" name="mutuario_empr" value="">
            </div>
            <input type="hidden" id="id_prod_empr" name="id_prod_empr" value="">      
            <button type="submit" class="btn btn-primary">Confirmar empréstimo</button>
        </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

        </div>
      </div>
    </div>
  </div>  

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>


    $(document).ready(function() {
      $('.btn-add').click(function() {
        $('#registrationModal').modal('show');
      });
    });
  </script>

<script>
$(document).ready(function() {
  var thisprod_id;

  $('.btn-editar').click(function() {
    thisprod_id = $(this).data('thisproduto_id');
    $('#id_prod').val(thisprod_id);

    $('#editarModalLabel').modal('show'); // Mostra o modal

  });

});
</script>

<script>
$(document).ready(function() {
  var thisprod_id;

  $('.btn-emprestimo').click(function() {
    thisprod_id = $(this).data('thisproduto_id');
    $('#id_prod_empr').val(thisprod_id);

    $('#emprestimoModalLabel').modal('show'); // Mostra o modal

  });

});
</script>

<script>
    $(document).ready(function() {
      $('.nav-link').click(function(e) {
        e.preventDefault();

        $('.nav-link').removeClass('active');
        $(this).addClass('active');
        if ($(this).hasClass('baba')) {
          $('#perfilModal').modal('show');
        }
      });
    });
  </script>

</script>
<script>
  function confirmDelete() {
    return confirm("Tem certeza que deseja excluir este produto?");
  }
</script>
  </body>
</html>