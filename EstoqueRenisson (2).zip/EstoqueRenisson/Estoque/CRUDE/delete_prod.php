<?php
require('../conn.php');

$id_prod = $_POST['id_prod'];
$causa_baixa = $_POST['causa_baixa'];

$produto = $id_prod;

$nome_prod = $pdo->prepare('SELECT nome_produto FROM produtos WHERE id_produto = ?');
$nome_prod->execute(array($id_prod));
$result = $nome_prod->fetch();
$nome_produto = $result['nome_produto'];

$cad_baixa = $pdo->prepare("INSERT INTO baixas (causa_baixa, nome_baixa) 
VALUES (:causa_baixa, :nome_baixa)");
$cad_baixa->execute(array(
    ':causa_baixa' => $causa_baixa,
    ':nome_baixa' => $nome_produto
));
 $del_prod = $pdo->prepare('DELETE FROM produtos WHERE id_produto = ?');
 $del_prod->execute(array($id_prod));

 header("Location: ../tabelas.php"); 
?>
