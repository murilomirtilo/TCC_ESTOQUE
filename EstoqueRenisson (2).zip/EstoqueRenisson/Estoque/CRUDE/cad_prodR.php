<?php
    require('../conn.php');

    $name_prod = $_POST['name_prod'];

    $local_prod = $_POST['local_prod'];
   
    if(empty($name_prod) || empty($local_prod)){
        echo "Os valores não podem ser vazios";
    }else{
        $cad_prod = $pdo->prepare("INSERT INTO produtosretornaveis(nome_produtoR, local_produtoR) 
        VALUES(:name_produtoR, :local_produtoR)");
        $cad_prod->execute(array(
            ':name_produtoR'=> $name_prod,
            ':local_produtoR'=> $local_prod
        ));

        echo "<script>
        alert('Produto Cadastrado com sucesso!');
        </script>";
        header("Location: ../tabelasPR.php");
    }
?> 