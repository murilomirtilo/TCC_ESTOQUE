<?php
    require('../conn.php');

    $vista_chave = $_POST['vista_chave'];
    $id_chave = $_POST['id_chave'];
    $disponivel_chave = $_POST['disponivel_chave'];

    $emprestar_chave = $pdo->prepare("UPDATE chaves SET vista_chave = 
    :vista_chave, disponivel_chave = 1 WHERE id_chave = :id_chave;");
    
    $emprestar_chave->execute(array(
        ':vista_chave' => $vista_chave,
        ':id_chave' => $id_chave
    ));

    header("Location: ../tabelasChave.php");
    echo 'sucesso';
?>
