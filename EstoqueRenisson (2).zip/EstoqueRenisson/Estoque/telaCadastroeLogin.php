<!DOCTYPE html>
<html>
<head>
  <title>Tela de Login e Cadastro</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .form-container {
      background-color: #f2f2f2;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .form-container input[type="text"],
    .form-container input[type="email"],
    .form-container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border-radius: 3px;
      border: 1px solid #ccc;
    }
    .form-container input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 3px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="form-container">
          <h2>Login</h2>
          <form action="logar.php" method="POST">
            <div class="form-group">
              <input type="text" class="form-control" name="login1" placeholder="Usuário" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" name="senha1" placeholder="Senha" required>
            </div>
            <div class="form-group">
              <input type="submit" class="btn btn-primary" value="Entrar">
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-container">
          <h2>Cadastro</h2>
          <form action="cadastrar.php" method="POST">
            <div class="form-group">
              <input type="text" class="form-control" name="login" placeholder="Usuário" required>
            </div>
            <div class="form-group">
              <input type="email" class="form-control" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" name="senha" placeholder="Senha" required>
            </div>
            <div class="form-group">
              <input type="submit" class="btn btn-primary" value="Cadastrar">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
