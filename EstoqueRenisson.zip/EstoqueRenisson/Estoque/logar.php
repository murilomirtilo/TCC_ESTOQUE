<?php
include("conn.php");
$login = $_POST['login1'];
$senha = $_POST['senha1'];

$usuario = $pdo->prepare('SELECT * FROM usuarios where login=:login AND senha=:senha');
$usuario->execute(array(':login'=>$login, ':senha'=>$senha));

$rowTabela = $usuario->fetchAll();

if (empty($rowTabela)){
    echo "<script>
    alert('Usuário e/ou senha inválidos!!!');
    </script>";
    
} else {
    $sessao = $rowTabela[0];

    if (!isset($_SESSION)) {
        session_start();    
    }
    $_SESSION['id'] = $sessao['id'];
    $_SESSION['login'] = $sessao['login'];
    $usuarioLogadoId = $_SESSION['id']; // Armazena o ID do usuário logado na variável $usuarioLogadoId
    header("Location: tabelas.php");
}
?>
