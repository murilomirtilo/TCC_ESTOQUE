<?php
    require('../conn.php');

    $id_chave = $_POST['id_chave'];
    $disponivel_chave = $_POST['disponivel_chave'];

    $devolver_chave = $pdo->prepare("UPDATE chaves SET disponivel_chave = 0 WHERE id_chave = :id_chave;");

    $devolver_chave->execute(array(
        ':id_chave' => $id_chave
    ));

    header("Location: ../tabelasChave.php");
    echo 'sucesso';
?>
